"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import seed from "@/data/seed-activities.json";
import { DEMO_FAMILIES } from "@/data/demo-families";
import { AREA_IDS, AREAS, ZONE_NAMES, ZONES, areaOfZone, zonesOf, type AreaId, type ZoneName } from "@/data/zones";
import { haversineKm, recommend } from "@/lib/engine/engine";
import type { Place } from "@/lib/explore/geo";
import { placeKey } from "@/lib/explore/places-store";
import { StartPicker, loadStart, saveStart } from "./home-location";
import type {
  Activity,
  Family,
  FamilyBudget,
  ScoredActivity,
  SettingPreference,
  WeekendWeather,
} from "@/lib/engine/types";
import { agesLabel, buildDraft } from "@/lib/mail/draft";
import { buildHtml, KID_COLORS } from "@/lib/mail/html";
import { fallbackWeather, getWeekendWeather } from "@/lib/weather/open-meteo";
import candidatesJson from "@/data/event-candidates.json";
import candidatesMeta from "@/data/event-candidates-meta.json";
import adultsJson from "@/data/event-adults.json";
import {
  eventWhen,
  loadImported,
  loadStore,
  mergeCandidates,
  pendingCandidates,
  saveImported,
  saveStore,
  type EventStoreData,
  type ImportedCandidates,
} from "@/lib/events/store";
import { EventsPanel } from "./events-panel";
import { AdultsPanel } from "./adults-panel";
import { ExplorePanel } from "./explore-panel";
import { hydrate } from "@/lib/persist";
import { fetchRemoteEvents, isNewer } from "@/lib/events/remote";
import { CURRENT_BUILD, checkUpdate, isNativeApp, type UpdateInfo } from "@/lib/update";

const ACTIVITIES = seed as Activity[];
const CANDIDATES = candidatesJson as Activity[];
const CANDIDATES_AT = (candidatesMeta as { generatedAt: string | null }).generatedAt;
const ADULTS = adultsJson as Activity[];
const MAX_CHILDREN = 8;
const BASE = DEMO_FAMILIES[0];

const BUDGETS: { v: FamilyBudget; l: string }[] = [
  { v: "free", l: "Solo gratis" },
  { v: "upto20", l: "Fino a 20 €" },
  { v: "20to50", l: "20–50 €" },
  { v: "over50", l: "Oltre 50 €" },
];
const PREFS: { v: SettingPreference; l: string }[] = [
  { v: "any", l: "Indifferente" },
  { v: "outdoor", l: "Preferibilmente all'aperto" },
  { v: "indoor", l: "Preferibilmente al coperto" },
];
const RADII = [5, 10, 20, 30, 50, 80];
const COST_LABEL = { free: "Gratis", low: "fino a 10 € a testa", mid: "10–25 € a testa", high: "oltre 25 € a testa" };

type RainMode = "live" | "dry" | "rain";

export function Demo() {
  const [ages, setAges] = useState<number[]>(BASE.childrenAges);
  const [zone, setZone] = useState<ZoneName>(BASE.zone as ZoneName);
  const area: AreaId = areaOfZone(zone);
  // Starting point for the proposals: a place (GPS, favourite, town) or, if null, the zone.
  const [start, setStart] = useState<Place | null>(null);
  const [weatherByKey, setWeatherByKey] = useState<Record<string, WeekendWeather>>({});
  const [radiusKm, setRadiusKm] = useState(BASE.radiusKm);
  const [budget, setBudget] = useState<FamilyBudget>(BASE.budget);
  const [preference, setPreference] = useState<SettingPreference>(BASE.preference);
  const [liveWeather, setLiveWeather] = useState<WeekendWeather | null>(null);
  const [placeholder, setPlaceholder] = useState<WeekendWeather | null>(null);
  const [rainMode, setRainMode] = useState<RainMode>("live");
  const [copied, setCopied] = useState(false);
  const [tab, setTab] = useState<"weekend" | "adulti" | "esplora" | "eventi">("weekend");
  const [store, setStore] = useState<EventStoreData>({ events: [], rejected: [] });
  const [imported, setImported] = useState<ImportedCandidates>({ generatedAt: null, events: [] });
  const [today, setToday] = useState<string>("");
  const [sync, setSync] = useState<string>("busy");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    // Date-dependent values are computed only in the browser (no prerender clock).
    queueMicrotask(() => {
      if (!alive) return;
      setPlaceholder(fallbackWeather());
      // Restore saved events from durable storage (survives app updates), then read them.
      void hydrate().finally(() => {
        if (!alive) return;
        setStore(loadStore());
        setImported(loadImported());
        setReady(true);
        const s = loadStart();
        if (s) setStart(s);
      });
      const d = new Date();
      setToday(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`);
    });
    return () => { alive = false; };
  }, []);

  // Automatic updates: weekly events from GitHub (merged only if newer than what the
  // phone has; approved/rejected events are never touched) and the APK version.
  const [update, setUpdate] = useState<UpdateInfo | null>(null);
  const refreshOnline = useCallback(async () => {
    setSync("busy");
    const r = await fetchRemoteEvents();
    if (r.ok && isNewer(r.data, loadImported())) {
      setImported(r.data);
      saveImported(r.data);
    }
    setSync(r.ok ? "ok" : r.reason);
    if (await isNativeApp()) setUpdate(await checkUpdate());
  }, []);

  // At every start, once saved data has been restored.
  useEffect(() => {
    if (ready) queueMicrotask(() => void refreshOnline());
  }, [ready, refreshOnline]);

  // Also when the app comes back to the foreground (at most every 30 minutes).
  useEffect(() => {
    let last = Date.now();
    const onVisible = () => {
      if (document.visibilityState !== "visible" || Date.now() - last < 30 * 60_000) return;
      last = Date.now();
      void refreshOnline();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [refreshOnline]);

  // Weather where the family starts from (a chosen place, else the area); fetched once per point.
  const weatherKey = start ? placeKey(start) : area;
  useEffect(() => {
    if (weatherByKey[weatherKey]) {
      queueMicrotask(() => setLiveWeather(weatherByKey[weatherKey] ?? null));
      return;
    }
    let alive = true;
    const at = start ?? AREAS[area];
    getWeekendWeather({ lat: at.lat, lng: at.lng }).then((w) => {
      if (!alive) return;
      setWeatherByKey((m) => ({ ...m, [weatherKey]: w }));
      setLiveWeather(w);
    });
    return () => { alive = false; };
  }, [weatherKey, start, area, weatherByKey]);

  function chooseStart(p: Place | null) {
    setStart(p);
    saveStart(p);
    if (!p) return;
    // Near one of our areas: align the zone (and so the Adulti/Eventi tabs) with it.
    const nearest = ZONE_NAMES.map((z) => ({ z, d: haversineKm(p.lat, p.lng, ZONES[z].lat, ZONES[z].lng) })).sort((a, b) => a.d - b.d)[0];
    if (nearest && nearest.d <= 60) setZone(nearest.z);
  }

  const weather: WeekendWeather | null = useMemo(() => {
    const w = liveWeather ?? placeholder;
    if (!w) return null;
    if (rainMode === "dry") return { ...w, rainy: false, rainProbability: 10, source: "open-meteo" };
    if (rainMode === "rain") return { ...w, rainy: true, rainProbability: 85, source: "open-meteo" };
    return w;
  }, [liveWeather, placeholder, rainMode]);

  const family: Family = useMemo(
    () => ({
      id: "demo",
      email: BASE.email,
      zone: start ? start.name : zone,
      lat: start ? start.lat : ZONES[zone].lat,
      lng: start ? start.lng : ZONES[zone].lng,
      radiusKm,
      childrenAges: ages,
      budget,
      preference,
      interests: [],
    }),
    [ages, zone, start, radiusKm, budget, preference],
  );

  const candidates = useMemo(() => mergeCandidates(CANDIDATES, CANDIDATES_AT, imported), [imported]);
  // Adults: adult agenda events + anything for everyone (sagre, feste) found online or approved by hand.
  const adultItems = useMemo(() => {
    const adults = mergeCandidates(ADULTS, CANDIDATES_AT, imported, "adults");
    const forAll = [...candidates, ...store.events].filter((e) => e.audience === "tutti" || e.audience === "adulti");
    const map = new Map<string, Activity>();
    for (const a of [...adults, ...forAll]) map.set(a.slug, a);
    return [...map.values()];
  }, [candidates, imported, store]);
  const updatedAt = [CANDIDATES_AT, imported.generatedAt].filter(Boolean).sort().pop() ?? null;
  const pending = useMemo(() => (today ? pendingCandidates(candidates, store, today) : []), [candidates, store, today]);
  // Home proposals: catalogue + approved events + events found online not yet rejected (marked "da verificare").
  const catalogue = useMemo(
    () => [
      ...ACTIVITIES,
      ...store.events.filter((e) => e.status === "published" && e.audience !== "adulti"),
      ...pending.filter((e) => e.audience !== "adulti"),
    ],
    [store, pending],
  );

  function importCandidates(next: ImportedCandidates) {
    setImported(next);
    saveImported(next);
  }
  const rec = useMemo(
    () => (weather ? recommend(family, catalogue, weather, { allowUnverified: true, now: new Date(weather.fetchedAt) }) : null),
    [family, weather, catalogue],
  );

  // Events this weekend within the radius (shown as a hint above the ideas).
  const eventsNear = useMemo(() => {
    if (!weather?.saturday || !weather.sunday) return 0;
    const sat = weather.saturday, sun = weather.sunday;
    return catalogue.filter((a) => {
      if (!a.event || a.lat == null || a.lng == null) return false;
      const end = a.event.endDate ?? a.event.date;
      return a.event.date <= sun && end >= sat && haversineKm(family.lat, family.lng, a.lat, a.lng) <= radiusKm;
    }).length;
  }, [catalogue, weather, family, radiusKm]);

  function updateStore(next: EventStoreData) {
    setStore(next);
    saveStore(next);
  }
  const draft = useMemo(() => (rec ? buildDraft(family, rec) : null), [family, rec]);
  const html = useMemo(() => (rec ? buildHtml(family, rec) : ""), [family, rec]);
  const kidColor = useMemo(() => colorByIndex(ages), [ages]);

  const setAge = (i: number, d: number) =>
    setAges((a) => a.map((x, j) => (j === i ? Math.min(17, Math.max(0, x + d)) : x)));

  async function copyDraft() {
    if (!draft) return;
    try {
      await navigator.clipboard.writeText(`${draft.subject}\n\n${draft.text}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      const el = document.getElementById("mail-body");
      if (el) window.getSelection()?.selectAllChildren(el);
    }
  }

  return (
    <div className="min-h-full">
      <header className="bg-shell text-on-shell">
        <div className="mx-auto flex max-w-2xl items-center justify-between gap-4 px-4 pt-4">
          <div className="flex min-w-0 flex-col">
            <h1 className="text-xl font-extrabold">Weekend in Famiglia</h1>
            <label className="flex items-center gap-1 text-sm text-on-shell-2">
              <span className="sr-only">Area</span>
              <select
                id="area"
                value={area}
                onChange={(e) => setZone(zonesOf(e.target.value as AreaId)[0])}
                className="cursor-pointer appearance-none rounded-full bg-black/15 py-0.5 pl-2.5 pr-6 font-semibold text-on-shell"
                style={{ backgroundImage: "linear-gradient(45deg, transparent 50%, currentColor 50%), linear-gradient(135deg, currentColor 50%, transparent 50%)", backgroundPosition: "calc(100% - 12px) 55%, calc(100% - 8px) 55%", backgroundSize: "4px 4px", backgroundRepeat: "no-repeat" }}
              >
                {AREA_IDS.map((a) => (
                  <option key={a} value={a} className="text-ink">{AREAS[a].label}</option>
                ))}
              </select>
            </label>
          </div>
          <WeatherBadge w={weather} live={liveWeather} />
        </div>
        {update && (
          <div className="mx-auto flex max-w-2xl flex-wrap items-center justify-between gap-2 px-4 pt-3 text-sm text-on-shell">
            <span>Nuova versione dell&apos;app disponibile. I tuoi eventi restano salvati.</span>
            <span className="flex gap-2">
              <a href={update.apkUrl} target="_blank" rel="noreferrer" className="rounded-full bg-accent px-3 py-1 font-semibold text-ink">Aggiorna</a>
              <button onClick={() => setUpdate(null)} className="rounded-full px-2 py-1 text-on-shell-2">Dopo</button>
            </span>
          </div>
        )}
        <nav aria-label="Sezioni" className="mx-auto flex max-w-2xl gap-1 px-4 pb-3 pt-3">
          {([["weekend", "Famiglia"], ["adulti", "Adulti"], ["esplora", "Esplora"], ["eventi", "Eventi"]] as const).map(([k, l]) => (
            <button
              key={k}
              aria-pressed={tab === k}
              onClick={() => setTab(k)}
              className={`flex items-center gap-1.5 rounded-full px-4 py-1.5 text-sm font-semibold transition-colors duration-150 ${
                tab === k ? "bg-on-shell text-shell" : "text-on-shell-2 hover:text-on-shell"
              }`}
            >
              {l}
              {k === "eventi" && pending.length > 0 && (
                <span className="num rounded-full bg-coral px-1.5 text-xs text-white">{pending.length}</span>
              )}
            </button>
          ))}
        </nav>
      </header>

      {tab === "esplora" ? (
        <main className="mx-auto flex max-w-2xl flex-col gap-6 px-4 py-6">
          <ExplorePanel
            catalogue={ACTIVITIES.filter((a) => a.status !== "draft")}
            events={[...store.events.filter((e) => e.audience !== "adulti"), ...candidates]}
            adults={adultItems}
          />
        </main>
      ) : tab === "adulti" ? (
        <main className="mx-auto flex max-w-2xl flex-col gap-6 px-4 py-6">
          <AdultsPanel items={adultItems} area={area} weather={weather} today={today} />
        </main>
      ) : tab === "eventi" ? (
        <main className="mx-auto flex max-w-2xl flex-col gap-6 px-4 py-6">
          {today ? <><EventsPanel store={store} onStore={updateStore} pending={pending} today={today} area={area} updatedAt={updatedAt} onImport={importCandidates} sync={sync} onSync={() => void refreshOnline()} />
          <p className="num text-center text-xs text-ink-2">
            {CURRENT_BUILD ? `Versione beta ${CURRENT_BUILD}` : "Versione di sviluppo"} · eventi approvati, scartati e preferiti restano sul telefono anche con gli aggiornamenti
          </p></> : <Skeleton />}
        </main>
      ) : (
      <main className="mx-auto flex max-w-2xl flex-col gap-6 px-4 py-6">
        {/* Children: the one control that matters */}
        <section className="flex flex-col gap-3 rounded-2xl border border-line bg-surface p-4">
          <h2 className="text-sm font-semibold">Età dei figli</h2>
          <div className="flex flex-wrap gap-2">
            {ages.map((age, i) => (
              <div key={i} className="flex items-center rounded-full border border-line bg-ground">
                <StepButton label={`Diminuisci età figlio ${i + 1}`} onClick={() => setAge(i, -1)} disabled={age <= 0}>−</StepButton>
                <span className="num flex min-w-[4rem] items-center justify-center gap-1.5 text-sm font-semibold"><span className="h-2.5 w-2.5 rounded-full" style={{ background: kidColor[i] }} />{age} anni</span>
                <StepButton label={`Aumenta età figlio ${i + 1}`} onClick={() => setAge(i, 1)} disabled={age >= 17}>+</StepButton>
                <button
                  aria-label={`Rimuovi figlio ${i + 1}`}
                  onClick={() => setAges((a) => a.filter((_, j) => j !== i))}
                  className="mr-1 flex h-7 w-7 items-center justify-center rounded-full text-ink-2 transition-colors duration-150 hover:bg-surface-2 hover:text-ink"
                >
                  <XIcon />
                </button>
              </div>
            ))}
            {ages.length < MAX_CHILDREN && (
              <button
                onClick={() => setAges((a) => [...a, 6])}
                className="rounded-full border border-dashed border-line px-3 py-1.5 text-sm text-link transition-colors duration-150 hover:border-ink-2"
              >
                + Aggiungi figlio
              </button>
            )}
          </div>

          <div className="border-t border-line pt-3">
            <StartPicker start={start} zone={zone} onStart={chooseStart} />
          </div>

          <details className="group">
            <summary className="flex cursor-pointer list-none items-center gap-1 text-sm text-ink-2 hover:text-ink">
              <Chevron />
              Altri filtri
              <span className="text-ink-2">· {start ? start.name : zone}, {radiusKm} km, {BUDGETS.find((b) => b.v === budget)?.l.toLowerCase()}</span>
            </summary>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Select id="zone" label="Zona di partenza" value={zone} onChange={(v) => { setZone(v as ZoneName); chooseStart(null); }}
                options={zonesOf(area).map((z) => ({ v: z, l: z }))} />
              <Select id="radius" label="Distanza massima" value={String(radiusKm)} onChange={(v) => setRadiusKm(Number(v))}
                options={RADII.map((r) => ({ v: String(r), l: `${r} km` }))} />
              <Select id="budget" label="Budget per uscita" value={budget} onChange={(v) => setBudget(v as FamilyBudget)}
                options={BUDGETS} />
              <Select id="pref" label="Preferenza" value={preference} onChange={(v) => setPreference(v as SettingPreference)}
                options={PREFS} />
            </div>
          </details>
        </section>

        {!weather || !rec || !draft ? (
          <Skeleton />
        ) : ages.length === 0 ? (
          <Empty text="Aggiungi almeno un figlio per vedere le proposte." />
        ) : rec.ideas.length === 0 ? (
          <Empty text="Nessuna attività con questi filtri. Prova ad aumentare distanza o budget in “Altri filtri”." />
        ) : (
          <>
            <section className="flex flex-col gap-3">
              <h2 className="text-base font-semibold">3 idee per figli di {agesLabel(ages)} <span className="font-normal text-ink-2">· da {start ? start.name : zone}</span></h2>
              {eventsNear > 0 && (
                <p className="-mt-1 text-xs text-ink-2">
                  <span className="num font-semibold text-coral">{eventsNear}</span> {eventsNear === 1 ? "evento" : "eventi"} questo weekend entro {radiusKm} km: hanno la precedenza se adatti ai tuoi figli.
                </p>
              )}
              <ol className="flex flex-col gap-3">
                {rec.ideas.map((s, i) => <Idea key={s.activity.slug} s={s} n={i + 1} ages={ages} colors={kidColor} />)}
              </ol>
            </section>

            {rec.planB && (
              <p className="flex items-start gap-2 text-sm text-ink-2">
                <span className="mt-0.5 text-rain"><RainIcon /></span>
                <span>
                  <span className="font-semibold text-ink">Se piove:</span>{" "}
                  <a href={rec.planB.activity.sourceUrl} target="_blank" rel="noreferrer" className="text-link underline-offset-4 hover:underline">
                    {rec.planB.activity.title}
                  </a>
                  {rec.planB.distanceKm != null && ` · ${km(rec.planB.distanceKm)}`}
                </span>
              </p>
            )}

            <details className="rounded-2xl border border-line bg-surface">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3">
                <span className="flex items-center gap-1 text-sm font-semibold"><Chevron /> Vedi la mail del venerdì</span>
                <span className="text-xs text-ink-2">bozza</span>
              </summary>
              <div className="border-t border-line">
                <p className="px-4 pt-3 text-sm font-medium">{draft.subject}</p>
                <iframe
                  title="Anteprima mail"
                  srcDoc={html}
                  sandbox=""
                  className="mt-3 block h-[1180px] w-full border-0 bg-[#f4f7ff]"
                />
                <pre id="mail-body" hidden>{draft.text}</pre>
                <div className="flex flex-wrap items-center gap-3 border-t border-line px-4 py-3">
                  <button onClick={copyDraft} className="rounded-lg border border-line px-3 py-1.5 text-sm font-medium transition-colors duration-150 hover:border-ink-2">
                    {copied ? "Copiato" : "Copia testo"}
                  </button>
                  <span className="text-xs text-ink-2">Così la vedranno le famiglie. Invio non ancora attivo.</span>
                </div>
              </div>
            </details>
          </>
        )}

        <footer className="flex flex-col gap-3 border-t border-line pt-4 text-xs text-ink-2">
          <div className="flex flex-wrap items-center gap-2">
            <span>Prova il meteo:</span>
            {(["live", "dry", "rain"] as RainMode[]).map((m) => (
              <button
                key={m}
                aria-pressed={rainMode === m}
                onClick={() => setRainMode(m)}
                className={`rounded-full px-2.5 py-1 transition-colors duration-150 ${
                  rainMode === m ? "bg-ink text-ground" : "bg-surface-2 hover:text-ink"
                }`}
              >
                {m === "live" ? "reale" : m === "dry" ? "sole" : "pioggia"}
              </button>
            ))}
          </div>
          <p>Demo con dati da verificare: orari, prezzi e posizioni vanno controllati prima dell&apos;invio.</p>
        </footer>
      </main>
      )}
    </div>
  );
}

/* ---------- pieces ---------- */

function Idea({ s, n, ages, colors }: { s: ScoredActivity; n: number; ages: number[]; colors: string[] }) {
  const a = s.activity;
  return (
    <li className="flex flex-col gap-2 rounded-2xl border border-line bg-surface p-4">
      <div className="flex items-start gap-3">
        <span className="num flex h-8 w-8 shrink-0 items-center justify-center rounded-full font-display text-base font-extrabold" style={NUM_STYLE[(n - 1) % 3]}>{n}</span>
        <div className="min-w-0">
          <h3 className="text-lg font-extrabold leading-snug">
            {a.sourceUrl ? (
              <a href={a.sourceUrl} target="_blank" rel="noreferrer" className="underline-offset-4 hover:underline">{a.title}</a>
            ) : (
              a.title
            )}
          </h3>
          {a.event && (
            <p className="num mt-1 inline-block rounded-full bg-coral px-2.5 py-0.5 text-xs font-semibold text-white">
              Solo questo weekend · {eventWhen(a)}
            </p>
          )}
          {a.event && a.status !== "published" && (
            <p className="text-xs text-ink-2">Trovato online · da verificare{a.event.organizer ? ` · ${a.event.organizer}` : ""}</p>
          )}
          <p className="num text-sm text-ink-2">
            {s.distanceKm != null ? km(s.distanceKm) : a.zone} · {COST_LABEL[a.costBand]}
            {a.bookingRequired ? " · su prenotazione" : ""}
          </p>
        </div>
      </div>
      <p className="text-sm">{a.description}</p>
      <AgeRuler min={a.minAge} max={a.maxAge} ages={ages} colors={colors} />
    </li>
  );
}

/** Activity age range on a 0–17 scale, with each child placed on it. */
function AgeRuler({ min, max, ages, colors }: { min: number; max: number; ages: number[]; colors: string[] }) {
  const W = 300;
  const pad = 8;
  const x = (age: number) => pad + (age / 17) * (W - pad * 2);
  const outside = ages.filter((g) => g < min || g > max);
  return (
    <div className="flex items-center gap-3">
      <svg viewBox={`0 0 ${W} 20`} className="block h-5 w-full max-w-[220px]" role="img" aria-label={`Adatto da ${min} a ${max} anni`}>
        <line x1={pad} x2={W - pad} y1={10} y2={10} style={{ stroke: "var(--line)" }} strokeWidth={3} strokeLinecap="round" />
        <line x1={x(min)} x2={x(max)} y1={10} y2={10} style={{ stroke: "var(--accent)" }} strokeWidth={8} strokeLinecap="round" />
        {ages.map((g, i) => {
          const ok = g >= min && g <= max;
          return (
            <circle key={i} cx={x(g)} cy={10} r={6} strokeWidth={2.5}
              style={ok ? { fill: colors[i], stroke: "var(--surface)" } : { fill: "var(--surface)", stroke: colors[i] }} />
          );
        })}
      </svg>
      <span className={`num shrink-0 text-xs ${outside.length ? "text-warn" : "text-ink-2"}`}>
        {min}–{max} anni{outside.length ? ` · ${outside.join(", ")} fuori fascia` : ""}
      </span>
    </div>
  );
}

function WeatherBadge({ w, live }: { w: WeekendWeather | null; live: WeekendWeather | null }) {
  const day = (d: string | null) => (d ? new Date(d + "T12:00:00").toLocaleDateString("it-IT", { day: "numeric", month: "short" }) : "");
  let label = "…";
  let icon = <SunIcon />;
  if (w?.source === "fallback") {
    label = live ? "meteo n.d." : "…";
    icon = <CloudIcon />;
  } else if (w?.rainy) {
    label = `pioggia ${w.rainProbability}%`;
    icon = <RainIcon />;
  } else if (w) {
    label = w.tempMax != null ? `sole · ${w.tempMax}°` : "sole";
  }
  return (
    <div className="flex items-center gap-2 text-sm">
      {icon}
      <span className="num">
        {w ? `${day(w.saturday)}–${day(w.sunday)}` : ""} <span className="text-on-shell-2">· {label}</span>
      </span>
    </div>
  );
}

function Select({ id, label, value, onChange, options }: {
  id: string; label: string; value: string; onChange: (v: string) => void; options: { v: string; l: string }[];
}) {
  return (
    <label htmlFor={id} className="flex flex-col gap-1 text-xs text-ink-2">
      {label}
      <select id={id} value={value} onChange={(e) => onChange(e.target.value)} className="field">
        {options.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
      </select>
    </label>
  );
}

function StepButton({ label, onClick, disabled, children }: {
  label: string; onClick: () => void; disabled?: boolean; children: React.ReactNode;
}) {
  return (
    <button aria-label={label} onClick={onClick} disabled={disabled}
      className="flex h-9 w-9 items-center justify-center rounded-full text-lg text-ink-2 transition-colors duration-150 hover:text-ink disabled:opacity-30">
      {children}
    </button>
  );
}

function Empty({ text }: { text: string }) {
  return <p className="rounded-2xl border border-dashed border-line px-6 py-10 text-center text-sm text-ink-2">{text}</p>;
}

function Skeleton() {
  return (
    <div className="flex flex-col gap-3" aria-busy="true" aria-label="Caricamento">
      {[0, 1, 2].map((i) => <div key={i} className="h-32 animate-pulse rounded-2xl bg-surface-2" />)}
    </div>
  );
}

const NUM_STYLE = [
  { background: "var(--coral)", color: "#ffffff" },
  { background: "var(--accent)", color: "#10223f" },
  { background: "var(--shell)", color: "#ffffff" },
];

/** Children keep a stable color by age order, matching the email. */
function colorByIndex(ages: number[]): string[] {
  const order = ages.map((a, i) => ({ a, i })).sort((p, q) => p.a - q.a || p.i - q.i);
  const out: string[] = [];
  order.forEach((o, rank) => { out[o.i] = KID_COLORS[rank % KID_COLORS.length]; });
  return out;
}

const km = (d: number) => `${d.toFixed(1).replace(".", ",")} km`;

/* ---------- icons ---------- */

function Svg({ children, size = 18 }: { children: React.ReactNode; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75}
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{children}</svg>
  );
}
const SunIcon = () => (
  <Svg><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></Svg>
);
const RainIcon = () => (
  <Svg><path d="M7 16a4 4 0 0 1-.5-7.97A6 6 0 0 1 18 9a3.5 3.5 0 0 1 0 7" /><path d="M9 19l-1 2M13 19l-1 2M17 19l-1 2" /></Svg>
);
const CloudIcon = () => (
  <Svg><path d="M7 18a4 4 0 0 1-.5-7.97A6 6 0 0 1 18 11a3.5 3.5 0 0 1 0 7z" /></Svg>
);
const XIcon = () => <Svg size={14}><path d="M6 6l12 12M18 6L6 18" /></Svg>;
const Chevron = () => (
  <span className="inline-flex transition-transform duration-150 group-open:rotate-90 [details[open]_&]:rotate-90">
    <Svg size={14}><path d="M9 6l6 6-6 6" /></Svg>
  </span>
);
